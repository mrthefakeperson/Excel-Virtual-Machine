#include <stdio.h>
int main()
{
  int a;
  scanf("%i", &a);
  printf("%i\n", a);
  scanf("%i", &a);
  scanf("%i", &a);
  printf("%i\n", a + 1);
  return 0;
}